package drone.delivery.com.company;

import java.sql.*;

public class JdbcExample {
    private Statement state = null;
    private Connection conn = null;
    private ResultSet resultSet = null;

    public JdbcExample(Statement mainState, Connection mainConn) {
        try {
            conn = mainConn;
            state = mainState;

            String sql;
            // Select Query
//            sql = "SELECT * FROM Customer";
//            ResultSet rs = state.executeQuery(sql);

//            while(rs.next()) {
//                String name = rs.getString("fullname");
//                int c_id = rs.getInt("customer_id");
//                String password = rs.getString("password");
//                String phone = rs.getString("phone");
//                String email = rs.getString("email");
//                String address = rs.getString("address");
//                String vip_level = rs.getString("VIP_Level");
//                int c_order_id = rs.getInt("customer_order_id");
//                Date c_since = rs.getDate("customer_since");
//                System.out.println(c_id + " | ");
//                System.out.println(password + " | ");
//                System.out.println(email + " | ");
//                System.out.println(address + " | ");
//                System.out.println(vip_level + " | ");
//                System.out.println(c_order_id + " | \n");
//            }

            // Create Query
            // sql = "INSERT INTO customer values( 'sanghun', '125241', '647-649', 'salri', '5720 student', '2', '2018-02-03', 1)";
            // state.executeUpdate(sql);

            // Update Query

            sql = "update Customer set fullname ='sanghun1', password='ttt' where fullname='sanghun'";
            state.executeUpdate(sql);
            conn.commit();

            resultSet = state
                    .executeQuery("select * from Customer where fullname='sanghun1'");

            while(resultSet.next()) {
                System.out.println(resultSet.getString("fullname") + '\n');
            }


        } catch(Exception e) {
            System.out.println(e);
            // error handling
        }
    }

    private void writeMetaData(ResultSet resultSet) throws SQLException {
        //  Now get some metadata from the database
        // Result set get the result of the SQL query

        System.out.println("The columns in the table are: ");

        System.out.println("Table: " + resultSet.getMetaData().getTableName(1));
        for  (int i = 1; i<= resultSet.getMetaData().getColumnCount(); i++){
            System.out.println("Column " +i  + " "+ resultSet.getMetaData().getColumnName(i));
        }
    }

}
