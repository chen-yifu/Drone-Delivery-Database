package drone.delivery.com.company.Model;

import java.sql.*;

public class Customer  {
    protected Statement state = null;
    protected Connection conn = null;
    public ResultSet resultSet = null;




    private String email;
    private String password;
    private int cid;
    private String cname;
    private String phone;
    private String address;
    private int VIP_Level;
    private Date sinceTime;

    public Customer(Statement mainState, Connection mainConn) {
        try {
            conn = mainConn;
            state = mainState;
        } catch (Exception e) {
            System.out.println(e);
            // error handling
        }
    }



    public void create(String fullname, String password, String phone, String email, String address) throws SQLException {
        String sql = "INSERT INTO customer values(default, ?, ?, ?, ?, ?, default, default)";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setString(1, fullname);
        ps.setString(2, password);
        ps.setString(3, phone);
        ps.setString(4, email);
        ps.setString(5, address);
        ps.executeUpdate();
        conn.commit();

    }


    public ResultSet read(String email, String password) throws SQLException {
        String sql = "Select * from customer where email=? and password=?";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setString(1, email);
        ps.setString(2, password);
        resultSet = ps.executeQuery();
        if (resultSet.next()) {
            return resultSet;
        } else {
            return null;
        }

    }


    public void update(int id, String fullname, String password, String phone, String address) throws SQLException {
        String sql = "update Customer set fullname = ?, password = ?, phone = ?, address =? where customer_id = ? limit 1";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setString(1, fullname);
        ps.setString(2, password);
        ps.setString(3, phone);
        ps.setString(4, address);
        //ps.setInt(5, VIP_Level);
        ps.setInt(5, id);
        ps.executeUpdate();
        conn.commit();
    }

    public void delete(int id) throws SQLException {
        String sql = "delete from customer where customer_id = ?";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setInt(1, id);
        ps.executeUpdate();
        conn.commit();
    }

    public void returnResultSet() throws SQLException {
        resultSet.next();
        System.out.println(resultSet.getString("fullname") + ", " +  resultSet.getString("email"));
    }

    public Boolean isDuplicated(String email, String phone) throws SQLException {
        boolean flag = false;
        String sql = "Select * from Customer where email=? or phone=?";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setString(1, email);
        ps.setString(2, phone);
        resultSet = ps.executeQuery();
        if (resultSet.next() != false) {
            flag = true;
        }
        return flag;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getEmail() {
        return email;
    }

    public String getPassword() {
        return password;
    }

    public Statement getState() {
        return state;
    }

    public int getCid() {
        return cid;
    }

    public String getCname() {
        return cname;
    }

    public String getPhone() {
        return phone;
    }

    public String getAddress() {
        return address;
    }

    public int getVIP_Level() {
        return VIP_Level;
    }

    public Date getSinceTime() {
        return sinceTime;
    }

    public void setCid(int cid) {
        this.cid = cid;
    }

    public void setCname(String cname) {
        this.cname = cname;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public void setVIP_Level(int VIP_Level) {
        this.VIP_Level = VIP_Level;
    }

    public void setSinceTime(Date sinceTime) {
        this.sinceTime = sinceTime;
    }
}
