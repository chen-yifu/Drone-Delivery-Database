package drone.delivery.com.company.Model;

import java.sql.*;

public class StoreStaff {
    protected Statement state = null;
    protected Connection conn = null;
    public ResultSet resultSet = null;

    private int staff_id;
    private String staff_name;
    private String password;
    private String phone;
    private String email;
    private String address;
    private String role;

    public StoreStaff(Statement mainState, Connection mainConn) {
        try {
            conn = mainConn;
            state = mainState;
        } catch (Exception e) {
            System.out.println(e);
            // error handling
        }
    }


    public void create(String fullname, String password, String phone, String email, String address) throws SQLException {
        String sql = "INSERT INTO store_Staff values(default, ?, ?, ?, ?, ?, ?, default)";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setString(1, fullname);
        ps.setString(2, password);
        ps.setString(3, phone);
        ps.setString(4, email);
        ps.setString(5, address);
        ps.executeUpdate();
        conn.commit();

    }


    public void update(int id, String fullname, String password, String phone, String address, String role) throws SQLException {
        String sql = "update store_staff set fullname = ?, password = ?, phone = ?, address =?, role =? where staff_id = ? limit 1";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setString(1, fullname);
        ps.setString(2, password);
        ps.setString(3, phone);
        ps.setString(4, address);
        ps.setString(5, role);
        ps.setInt(4, id);
        ps.executeUpdate();
        conn.commit();
    }



    public void getByLogin(String email, String password)  throws SQLException {
        String sql = "Select * from Store_Staff where email=? and password=?";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setString(1, email);
        ps.setString(2, password);
        resultSet = ps.executeQuery();
    }

    public void read(int id) throws SQLException {
        String sql = "Select * from Store_Staff where staff_id=?";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setInt(1, id);
        resultSet = ps.executeQuery();
    }

    public void returnResultSet() throws SQLException {
        resultSet.next();
        System.out.println(resultSet.getString("fullname") + ", " +  resultSet.getString("email"));
    }

    public void setStaff_id(int staff_id) {
        this.staff_id = staff_id;
    }

    public void setStaff_name(String staff_name) {
        this.staff_name = staff_name;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public int getStaff_id() {
        return staff_id;
    }

    public String getStaff_name() {
        return staff_name;
    }

    public String getPassword() {
        return password;
    }

    public String getPhone() {
        return phone;
    }

    public String getEmail() {
        return email;
    }

    public String getAddress() {
        return address;
    }

    public String getRole() {
        return role;
    }
}
