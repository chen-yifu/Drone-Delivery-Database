package drone.delivery.com.company.Model;

import java.sql.*;

public class Payment {
    private Statement state = null;
    private Connection conn = null;
    private ResultSet resultSet = null;

    private int paymentMethod;

    public Payment(Statement mainState, Connection mainConn) {
        try {
            conn = mainConn;
            state = mainState;
        } catch (Exception e) {
            System.out.println(e);
            // error handling
        }
    }
    public void create(int order_id, int payment_method_id, String SN, double amount, String status) throws SQLException {
        String sql = "insert into Payment values(default, ?, ?, ?, ?, ?)";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setInt(1,order_id);
        ps.setInt(2,payment_method_id);
        ps.setString(3,SN);
        ps.setDouble(4,amount);
        ps.setString(5,status);
        ps.executeQuery();
        conn.commit();
    }

    public ResultSet getPaymentMethodByPaymentID(int payment_id) throws SQLException {
        String sql = "select pm.fullname from Payment p JOIN Payment_Method pm ON p.payment_method_id = pm.id where payment_id = ?";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setInt(1,payment_id);
        resultSet = ps.executeQuery();
        if (resultSet.next()) {
            return resultSet;
        } else {
            return null;
        }
    }

    public void delete(int payment_id) throws SQLException {
        String sql = "delete from Payment where payment_id = ?";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setInt(1,payment_id);
        ps.executeQuery();
        conn.commit();
    }
    public void update(int payment_id, int payment_method_id) throws SQLException {
        String sql = "update Payment set payment_method_id = ? where payment_id = ?";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setInt(1,payment_method_id);
        ps.setInt(2,payment_id);
        ps.executeQuery();
        conn.commit();
    }

    public void returnResultSet() throws SQLException {
        resultSet.next();
        System.out.println("Payment Method is: " + resultSet.getInt("fullname"));
    }

    public void setPaymentMethod(int paymentMethod) {
        this.paymentMethod = paymentMethod;
    }

    public int getPaymentMethod() {
        return paymentMethod;
    }
}

