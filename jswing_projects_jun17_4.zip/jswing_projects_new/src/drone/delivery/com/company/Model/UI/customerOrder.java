package drone.delivery.com.company.Model.UI;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import static drone.delivery.com.company.Main.mainFrame;

public class customerOrder {
    public JPanel panel1;
    private JButton submitButton;
    private JTextField addressTextField;
    private JTextField phoneTextField;
    private JTextField commentTextField;
    private JLabel successMessage;

    public customerOrder() {
        submitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mainFrame.getContentPane().removeAll();
                mainFrame.repaint();
                mainFrame.setContentPane(new customer().panel1);
                mainFrame.repaint();
                mainFrame.setVisible(true);
            }
        });
    }

    private void createUIComponents() {
        // TODO: place custom component creation code here
    }
}
