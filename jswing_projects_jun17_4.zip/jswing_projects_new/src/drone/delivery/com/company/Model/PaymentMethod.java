package drone.delivery.com.company.Model;

import org.omg.CORBA.CODESET_INCOMPATIBLE;

import java.sql.*;

public class PaymentMethod {
    protected Statement state = null;
    protected Connection conn = null;
    public ResultSet resultSet = null;

    private String paymentMethodName;
    public PaymentMethod(Statement mainState, Connection mainConn) {
        try {
            conn = mainConn;
            state = mainState;
        } catch (Exception e) {
            System.out.println(e);
            // error handling
        }
    }

    public void create(String fullname, String comment) throws SQLException {
        String sql = "insert into Payment_Method values(default, ?, ?)";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setString(1,fullname);
        ps.setString(2,comment);
        ps.executeQuery();
        conn.commit();

    }

    public ResultSet read(int id) throws SQLException {
        String sql = "select fullname from Payment_Method where id = ?";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setInt(1,id);
        resultSet = ps.executeQuery();
        if (resultSet.next()) {
            return resultSet;
        } else {
            return null;
        }

    }
    public void delete(int id) throws SQLException {
        String sql = "delete from Payment_Method where id = ?";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setInt(1,id);
        ps.executeQuery();
        conn.commit();
    }
    public void update(int id, String fullname, String comment) throws SQLException {
        String sql = "update Payment_Method set fullname = ?, comment = ? where id = ?";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setString(1,fullname);
        ps.setString(2, comment);
        ps.setInt(3,id);
        ps.executeQuery();
    }

    public void returnResultSet() throws SQLException {
        resultSet.next();
        System.out.println(resultSet.getInt("id") + ", " + resultSet.getString("fullname") + ", " + resultSet.getString("comment"));
    }

    public String getPaymentMethodName() {
        return paymentMethodName;
    }

    public void setPaymentMethodName(String paymentMethodName) {
        this.paymentMethodName = paymentMethodName;
    }
}

