package drone.delivery.com.company.Model;

import java.sql.*;

public class StoreOperatingHour {
    private Statement state = null;
    private Connection conn = null;
    public ResultSet resultSet = null;

    public StoreOperatingHour(Statement mainState, Connection mainConn) {
        try {
            conn = mainConn;
            state = mainState;
        } catch (Exception e) {
            System.out.println(e);
            // error handling
        }
    }

    public void create(String fullname, String address, String close, String open, int rating, String type) throws SQLException {
        String sql = "INSERT INTO Stroe_Operating_Hour values(?,?,?,?,?,?)";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setString(1, fullname);
        ps.setString(2, address);
        ps.setString(3, close);
        ps.setString(4, open);
        ps.setInt(5, rating);
        ps.setString(6, type);
        ps.executeUpdate();
        conn.commit();
    }

    public void read(String fullname, String address) throws SQLException {
        String sql = "Select * from  Store_Operating_Hour where fullname=? and address =?";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setString(1, fullname);
        ps.setString(2, address);
        resultSet = ps.executeQuery();
    }

    public void returnResultSet() throws SQLException {
        resultSet.next();
        System.out.println(resultSet.getString("address") + "," + resultSet.getString("open_hour") + ","
                + resultSet.getString("close_hour") + "," + resultSet.getString("rating")
                + " ," + resultSet.getString("type"));
    }


}

