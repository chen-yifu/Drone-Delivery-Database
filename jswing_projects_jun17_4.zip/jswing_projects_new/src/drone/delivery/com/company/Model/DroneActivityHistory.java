package drone.delivery.com.company.Model;

import java.sql.*;

public class DroneActivityHistory {
    private Statement state = null;
    private Connection conn = null;
    public ResultSet resultSet = null;

    public DroneActivityHistory(Statement mainState, Connection mainConn) {
        try {
            conn = mainConn;
            state = mainState;
        } catch (Exception e) {
            System.out.println(e);
            // error handling
        }
    }

    public void create(int drone_id, String status, Date update_at, Date create_at, int order_id, String gps_location) throws SQLException {
        String sql = "insert into DroneActivityHistory values(default,?,?,?,?,?,?)";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setInt(1,drone_id);
        ps.setString(2,status);
        ps.setDate(3,update_at);
        ps.setDate(4,create_at);
        ps.setInt(5,order_id);
        ps.setString(6,gps_location);
        ps.executeQuery();
        conn.commit();
    }

    public void read(int history_id) throws SQLException {
        String sql = "select * from Drone_Activity_History where history_id = ?";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setInt(1,history_id);
        resultSet = ps.executeQuery();
    }
    public void delete(int history_id) throws SQLException {
        String sql = "delete from Drone_Activity_History where history_id = ?";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setInt(1, history_id);
        conn.commit();
    }
    public void update(int history_id, String status, String gps_location) throws SQLException {
        String sql = "update Drone_Activity_History set status = ?, gps_location = ? where history_id = ?";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setString(1,status);
        ps.setString(2,gps_location);
        ps.setInt(3,history_id);
        conn.commit();
    }

    public void returnResultSet() throws SQLException{
        resultSet.next();
        System.out.println(resultSet.getInt("history_id"));
    }
}
