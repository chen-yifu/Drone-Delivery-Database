package drone.delivery.com.company.Model.UI;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import static drone.delivery.com.company.Main.mainFrame;
import static drone.delivery.com.company.Main.userController;

public class customerOrderStatus {
    protected JPanel panel1;
    private JTextField whatIsTheOrderTextField;
    private JButton trackStatusButton;
    private JButton backButton;
    private JLabel statusMessage;

    public customerOrderStatus() {
        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mainFrame.getContentPane().removeAll();
                mainFrame.repaint();
                mainFrame.setContentPane(new customer().panel1);
                mainFrame.repaint();
                mainFrame.setVisible(true);
            }
        });
        trackStatusButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // TODO implement track order status here; you can print the output by changing the value of the variable "whatIsTheOrderTextField" above.
                String status = "";
                try {
                    status = userController.getTheOrderIDAndDeliverStatus(Integer.parseInt(whatIsTheOrderTextField.getText()));
                    statusMessage.setText(status);
                    System.out.println("Got order status: " + status);
                } catch (Exception ex) {
                    status = "an error occurred.";
                    statusMessage.setText(status);
                    System.out.println("Got order status failed.");
                }
            }
        });
    }
}
