package drone.delivery.com.company.Model;

import com.sun.xml.internal.ws.developer.EPRRecipe;

import java.sql.*;


public class StaffFullfillsOrder {
    protected Statement state = null;
    protected Connection conn = null;
    public ResultSet resultSet = null;

    public StaffFullfillsOrder(Statement mainState, Connection mainConn) {
        try {
            conn = mainConn;
            state = mainState;
        } catch (Exception e) {
            System.out.println(e);
            // error handling
        }
    }


    public void create(int staff_id, int order_id, Date fulfill_time, String status) throws SQLException {
        String sql = "insert into Staff_Fullfills_Order values(?,?,?,?)";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setInt(1,staff_id);
        ps.setInt(2,order_id);
        ps.setDate(3,fulfill_time);
        ps.setString(4,status);
        ps.executeQuery();
        conn.commit();

    }

    // select the name of staff who fulfill all the orders
    // Division
    public void getTheStaffFulfilledAllOrders() throws SQLException {
        String sql = "select s.staff_fullname from Store_Staff s where not exists(select o.order_id from Orders o where not exists(select sf.staff_id from Staff_Fullfills_Order sf where s.staff_id = sf.staff_id and sf.order_id = o.order_id))";
        PreparedStatement ps = conn.prepareStatement(sql);
        resultSet = ps.executeQuery();
    }
    public void delete(int staff_id, int order_id) throws SQLException {
        String sql = "delete from Staff_Fullfills_Order where staff_id = ? and order_id = ?";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setInt(1,staff_id);
        ps.setInt(2,order_id);
        ps.executeQuery();
        conn.commit();
    }
    public void update(int staff_id, int order_id, String status) throws SQLException {
        String sql = "update Staff_Fullfills_Order set status = ? where staff_id = ? and order_id = ?";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setString(1,status);
        ps.setInt(2,staff_id);
        ps.setInt(3,order_id);
        ps.executeQuery();
        conn.commit();
    }

    public void returnResultSet() throws SQLException {
        while(resultSet.next()) {
            System.out.println("Staffs: " + resultSet.getInt("staff_fullname"));
        }

    }


}

