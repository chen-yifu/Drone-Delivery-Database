package drone.delivery.com.company.Model.UI;

import drone.delivery.com.company.Model.Store;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import static drone.delivery.com.company.Main.*;

public class customer {
    protected JPanel panel1;
    private JButton makeOrderButton;
    private JButton homeButton;
    private JButton getOrderStatusButton;
    private JList restaurantsList;
    private JButton refreshButton;
    private JTextField minField;
    private JTextField maxField;
    private JButton filterRestaurantsButton;

    public customer() {
//        try {List<Store> restaurants = userController.getStores();
//            }
        DefaultListModel listModel = new DefaultListModel();
        listModel.addElement("                                                ");
        restaurantsList.setModel(listModel);
        restaurantsList.revalidate();
        restaurantsList.repaint();

        homeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mainFrame.getContentPane().removeAll();
                mainFrame.repaint();
                mainFrame.setContentPane(new mainUI().panel1);
                mainFrame.repaint();
                mainFrame.setVisible(true);
            }
        });

        getOrderStatusButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mainFrame.getContentPane().removeAll();
                mainFrame.repaint();
                mainFrame.setContentPane(new customerOrderStatus().panel1);
                mainFrame.repaint();
                mainFrame.setVisible(true);
            }
        });
//        makeOrderButton.addActionListener(new ActionListener() {
//            @Override
//            public void actionPerformed(ActionEvent e) {
//                // TODO (optional): implement make order logic here, but this feature isn't included in Hao Ran's list so we can ignore it
//                mainFrame.getContentPane().removeAll();
//                mainFrame.repaint();
//                mainFrame.setContentPane(new customerPaymentMethods().panel1);
//                mainFrame.repaint();
//                mainFrame.setVisible(true);
//
//            }
//        });
        refreshButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                DefaultListModel listModel = new DefaultListModel();
                try {
                    ArrayList<Store> stores = userController.getStores();
                    for (Store s : stores) {
                        String row = "%s, %s, %s, open: %s, close: %s, %s stars, %s";
                        row = String.format(row, s.getFullname(), s.getPhone(), s.getAddress(),
                                s.getOpen_hour(), s.getClose_hour(), s.getRating(), s.getType());
                        listModel.addElement(row);
                    }
                } catch (Exception ex) {
                    System.out.println("Error occurred.");
                }
                restaurantsList.setModel(listModel);
                restaurantsList.revalidate();
                restaurantsList.repaint();

            }
        });
        filterRestaurantsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                DefaultListModel listModel = new DefaultListModel();
                try {
                    ArrayList<Store> stores = userController.getStoreByAvgCalorie(Integer.parseInt(minField.getText())
                            ,Integer.parseInt(maxField.getText()));
                    ArrayList<Store> allStores = userController.getStores();
                    for (Store s : allStores) {
                        if (stores.contains(s)) {
                            String row = "%s, %s, %s, open: %s, close: %s, %s stars, %s";
                            row = String.format(row, s.getFullname(), s.getPhone(), s.getAddress(),
                                    s.getOpen_hour(), s.getClose_hour(), s.getRating(), s.getType());
                            listModel.addElement(row);
                        }
                    }
                } catch (Exception ex) {
                    System.out.println("Error occurred.");
                }
                restaurantsList.setModel(listModel);
                restaurantsList.revalidate();
                restaurantsList.repaint();

            }
        });
    }
}
