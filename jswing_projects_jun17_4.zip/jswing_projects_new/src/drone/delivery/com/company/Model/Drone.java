package drone.delivery.com.company.Model;

import java.sql.*;

public class Drone {
    private Statement state = null;
    private Connection conn = null;
    public ResultSet resultSet = null;

    public Drone(Statement mainState, Connection mainConn) {
        try {
            conn = mainConn;
            state = mainState;
        } catch (Exception e) {
            System.out.println(e);
            // error handling
        }
    }

    public void create(int drone_id, String model, int capacity, String gps_location, String status) throws SQLException {
        String sql = "insert into Drone values(?,?,?,?,?)";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setInt(1,drone_id);
        ps.setString(2,model);
        ps.setInt(3,capacity);
        ps.setString(4,gps_location);
        ps.setString(5,status);
        ps.executeQuery();
        conn.commit();
    }

    public void read(int drone_id) throws SQLException {
        String sql = "select * from Drone where drone_id = ?";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setInt(1,drone_id);
        resultSet = ps.executeQuery();

    }
    public void delete(int drone_id) throws SQLException {
        String sql = "delete from Drone where drone_id = ?";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setInt(1,drone_id);
        ps.executeQuery();
        conn.commit();
    }
    public void update(int drone_id, String gps_location, String status) throws SQLException {
        String sql = "update Drone set gps.location = ?, status = ? where drone_id = ?";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setString(1,gps_location);
        ps.setString(2,status);
        ps.setInt(3,drone_id);
        ps.executeQuery();
        conn.commit();

    }

    public void returnResultSet() throws SQLException{
        resultSet.next();
        System.out.println(resultSet.getInt("drone_id"));
    }
}
