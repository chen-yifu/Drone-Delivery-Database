package drone.delivery.com.company.Model;

import java.sql.*;
import java.util.Date;

public class Orders {
    private Statement state = null;
    private Connection conn = null;
    public ResultSet resultSet = null;

    private int order_id;
    private String order_name;
    private String deliver_status;
    private Date estimated_time;

    public Orders(Statement mainState, Connection mainConn) {
        try {
            conn = mainConn;
            state = mainState;
        } catch (Exception e) {
            System.out.println(e);
            // error handling
        }
    }
    public void create(String status, String comment, int customer_id,
                       int drone_id, String delivery_status, String address, int store_id) throws SQLException {
        String sql = "insert into Orders values(default,?,?,?,?,default,?,default,?,default,?)";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setString(1,status);
        ps.setString(2,comment);
        ps.setInt(3,customer_id);
        ps.setInt(4,drone_id);
        ps.setString(5,delivery_status);
        ps.setString(6,address);
        ps.setInt(7,store_id);
        ps.executeQuery();
        conn.commit();
    }

    public ResultSet checkOrderDeliveryStatus(int order_id) throws SQLException, NullPointerException {
        String sql = "select order_id, deliver_status from Orders where order_id = ?";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setInt(1,order_id);
        resultSet = ps.executeQuery();
        if (resultSet.next()) {
            return resultSet;
        }
        return null;
    }

    public void delete(int order_id) throws SQLException {
        String sql = "delete from Orders where order_id = ?";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setInt(1, order_id);
        ps.executeUpdate();
        conn.commit();
    }
    public void updateStatus(String status, int order_id) throws SQLException {
        String sql = "update Orders set deliver_status = ? where order_id = ?";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setString(1,status);
        ps.setInt(2, order_id);
        ps.executeUpdate();
        conn.commit();
    }
    public void returnResultSet() throws SQLException {
        resultSet.next();
        System.out.println(resultSet.getInt("order_id") + ", " +  resultSet.getString("deliver_status"));
    }

    public int getOrder_id() {
        return order_id;
    }

    public String getOrder_name() {
        return order_name;
    }

    public void setOrder_id(int order_id) {
        this.order_id = order_id;
    }

    public void setOrder_name(String order_name) {
        this.order_name = order_name;
    }

    public String getDeliver_status() {
        return deliver_status;
    }

    public void setDeliver_status(String deliver_status) {
        this.deliver_status = deliver_status;
    }

    public Date getEstimated_time() {
        return estimated_time;
    }

    public void setEstimated_time(Date estimated_time) {
        this.estimated_time = estimated_time;
    }
}
