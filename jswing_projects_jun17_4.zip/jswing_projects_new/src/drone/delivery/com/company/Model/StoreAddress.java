package drone.delivery.com.company.Model;

import java.sql.*;

public class StoreAddress {
    private Statement state = null;
    private Connection conn = null;
    public ResultSet resultSet = null;

    public StoreAddress(Statement mainState, Connection mainConn) {
        try {
            conn = mainConn;
            state = mainState;
        } catch (Exception e) {
            System.out.println(e);
            // error handling
        }
    }

    public void create(String fullname, String phone, String address) throws SQLException { // list info
        String sql = "INSERT INTO Store_Address values( ?, ?, ?)";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setString(1, fullname);
        ps.setString(2, phone);
        ps.setString(3, address);
        ps.executeUpdate();
        // this.setUpOperationHrs(fullname, address, );
        conn.commit();
    }

    public void read(String fullname, String phone) throws SQLException {
        // getting address first
        String sql = "Select * from  Store_Address where fullname=? and phone =?";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setString(1, fullname);
        ps.setString(2, phone);
        ResultSet rs = ps.executeQuery();
        // using founded address, get info of operation time
        if(rs.next()) {
            String address = rs.getString("address");
            StoreOperatingHour s = new StoreOperatingHour(state, conn);
            s.read(fullname, address);
        }
    }

    public void getStores() throws SQLException {
        String sql = "Select *, sci.store_id from Store_Address sa inner join Store_Contact_Info sci ON sa.fullname = sci.fullname and sa.phone = sci.phone";
        PreparedStatement ps =conn.prepareStatement(sql);
        resultSet = ps.executeQuery();
        while (resultSet.next()) {
            System.out.println(resultSet.getString("fullname") + "," + resultSet.getString("phone") + "," + resultSet.getString("address") + ",");
        }

    }



    public void update(String fullname, String phone, String address) throws SQLException { // update Store info
        String sql = "update Store_Address set address = ? where fullname = ? and phone = ?";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setString(1, "address");
        ps.setString(2, "fullname");
        ps.setString(3, "phone");
        resultSet = ps.executeQuery();
        conn.commit();
    }

    public void returnResultSet() throws SQLException {
        resultSet.next();
        System.out.println(resultSet.getString("address") + "," + resultSet.getString("open_hour") + ","
                + resultSet.getString("close_hour") + "," + resultSet.getString("rating")
                + " ," + resultSet.getString("type"));
    }
}
