package drone.delivery.com.company.Model.UI;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import static drone.delivery.com.company.Main.mainFrame;
import static drone.delivery.com.company.Main.userController;

public class sellerUpdateCustomer {
    public JPanel panel1;
    private JTextField customerIDTextField;
    private JTextField fullnameTextField;
    private JTextField passwordTextField;
    private JTextField phoneTextField;
    private JTextField addressTextField;
    private JButton updateButton;

    public sellerUpdateCustomer() {
        updateButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // updateCustomerInfo(int id, String fullname, String password, String phone, String address)
                try {
                    userController.updateCustomerInfo(Integer.parseInt(customerIDTextField.getText()), fullnameTextField.getText()
                            , passwordTextField.getText(), phoneTextField.getText(), addressTextField.getText());
                    System.out.println("Updated customer.");
                } catch (Exception ex) {
                    System.out.println("Update customer failed.");
                }
                mainFrame.getContentPane().removeAll();
                mainFrame.repaint();
                mainFrame.setContentPane(new drone.delivery.com.company.Model.UI.seller().panel1);
                mainFrame.repaint();
                mainFrame.setVisible(true);
            }
        });
    }
}
