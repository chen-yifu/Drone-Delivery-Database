package drone.delivery.com.company.Model.UI;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import static drone.delivery.com.company.Main.mainFrame;
import static drone.delivery.com.company.Main.userController;

public class customerRegister {
    private JTextField emailTextField;
    private JTextField passwordTextField;
    private JTextField fullnameField;
    private JTextField phoneField;
    private JTextField addressField;
    public JButton registerButton;
    public JPanel panel1;
    private JButton homeButton;

    public customerRegister() {
        homeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mainFrame.getContentPane().removeAll();
                mainFrame.repaint();
                mainFrame.setContentPane(new drone.delivery.com.company.Model.UI.mainUI().panel1);
                mainFrame.repaint();
                mainFrame.setVisible(true);
            }
        });
        registerButton.addActionListener(new ActionListener() {
            // TODO: implement registration logic
            @Override
            public void actionPerformed(ActionEvent e) {
                //register(String fullname, String password, String phone, String email, String address){
                userController.register(fullnameField.getText(), passwordTextField.getText(), phoneField.getText(), emailTextField.getText(),addressField.getText());
                mainFrame.getContentPane().removeAll();
                mainFrame.repaint();
                mainFrame.setContentPane(new mainUI().panel1);
                mainFrame.repaint();
                mainFrame.setVisible(true);
                System.out.println("New customer registered.");
            }
        });
    }
}
