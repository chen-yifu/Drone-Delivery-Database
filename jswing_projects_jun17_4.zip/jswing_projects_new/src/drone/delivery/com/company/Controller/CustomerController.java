package drone.delivery.com.company.Controller;


import drone.delivery.com.company.Model.*;
import sun.java2d.xr.XRRenderer;

import java.sql.*;
import java.util.ArrayList;


public class CustomerController {
    private Statement st;
    private Connection conn;
    private Customer customer;


    public CustomerController(Statement st, Connection conn) {
        try {
            this.st = st;
            this.conn = conn;
            customer = new Customer(st,conn);
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }


    }

    public Statement getSt() {
        return st;
    }

    public Connection getConn() {
        return conn;
    }

    public void setSt(Statement st) {
        this.st = st;
    }

    public void setConn(Connection conn) {
        this.conn = conn;
    }

    // insert
    public void register(String fullname, String password, String phone, String email, String address){
        try  {
            if (!customer.isDuplicated(email,phone)) {
                customer.create(fullname,password,phone,email,address);
            }

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

    }

    // delete
    public void deleteInvalidCustomer(int customer_id) {
        Customer customer = new Customer(st,conn);
        try {
            customer.delete(customer_id);
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    // update
    public void updateCustomerInfo(int id, String fullname, String password,
                                   String phone, String address) {
        Customer customer = new Customer(st,conn);
        try{
            customer.update(id,fullname,password,phone,address);
        } catch (Exception e) {
            System.out.println(e);
        }
    }


    // selection
    public Customer login(String email, String password) throws NullPointerException {
        Customer cus = new Customer(st,conn);
        try {
            ResultSet rs = cus.read(email,password);
            cus.setEmail(rs.getString("email"));
            cus.setPassword(rs.getString("password"));
        } catch (Exception e) {
            return null;
        }
        return cus;
    }

    // join
    public String showPaymentMethod(int payment_id) {
        Payment p = new Payment(st,conn);
        PaymentMethod pm = new PaymentMethod(st,conn);
        try{
            ResultSet rs1 = p.getPaymentMethodByPaymentID(payment_id);
            String str = rs1.getString("fullname");
            pm.setPaymentMethodName(str);
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        return pm.getPaymentMethodName();
    }

    // As a customer, i would like to select stores which can ensure that the items' avg calorie should be in my accepted range
    // select a store with its name and store_id, which can ensure that the items' avg calorie in this store is in the given range

    // aggregation
//    public String getStoreByAvgCalorie(int low_calorie, int high_calorie) {
//        Item i = new Item(st,conn);
//        StoreContactInfo sci = new StoreContactInfo(st,conn);
//        try {
//            ResultSet rs1 = i.selectStoreByAvgCalorie(low_calorie,high_calorie);
//            String name = rs1.getString("store_name");
//            sci.setStoreName(name);
//        } catch(Exception e) {
//            System.out.println(e.getMessage());
//        }
//        return sci.getStoreName();
//    }


    public ArrayList<Store> getStoreByAvgCalorie(int low_calorie, int high_calorie) throws SQLException {
        ArrayList<Store> stores = new ArrayList<>();
        String sql = "select sc.fullname as store_name from Item i, Store_Contact_Info sc where i.store_id = sc.store_id group by store_name having avg(calorie) >= ? and avg(calorie) <= ?";
        PreparedStatement ps = conn.prepareStatement(sql);
        ResultSet rs;
        ps.setInt(1,low_calorie);
        ps.setInt(2,high_calorie);
        rs = ps.executeQuery();
        addToStoresWithAvgCalorie(stores,rs);
        return stores;
    }

    // helper for getStoreByAvgCalorie
    private void addToStoresWithAvgCalorie(ArrayList<Store> stores, ResultSet rs) throws SQLException {
        while (rs.next()) {
            Store store = new Store();
            store.setFullname(rs.getString("store_name"));
            stores.add(store);
        }
    }

    // select customer with id and name who buy the items whose quantity >= bound so that it can upgrade the VIP_level
    // nested-subquery
    public ArrayList<Customer> countByQuantity(int bound) throws SQLException {
        ArrayList<Customer> customers = new ArrayList<>();
        String sql = "SELECT c.customer_id, c.fullname FROM Customer c where c.customer_id in (select c.customer_id from Orders o, Order_Contains_Item oc where c.customer_id = o.customer_id and oc.order_id = o.order_id group by o.customer_id having sum(quantity) >= ?)";
        PreparedStatement ps = conn.prepareStatement(sql);
        ResultSet resultSet;
        ps.setInt(1,bound);
        resultSet = ps.executeQuery();
        addToArrayList(customers,ps,resultSet);
        return customers;
    }

    // helper function for countByQuantity
    private void addToArrayList(ArrayList customers, PreparedStatement ps, ResultSet resultSet) throws SQLException {
        while(resultSet.next()) {
            Customer cus = new Customer(ps,conn);
            cus.setCid(resultSet.getInt("customer_id"));
            cus.setCname(resultSet.getString("fullname"));
            customers.add(cus);
        }
    }

    // projection
    public String getTheOrderIDAndDeliverStatus(int order_id) {
        Orders o = new Orders(st,conn);
        try{
            ResultSet rs = o.checkOrderDeliveryStatus(order_id);
            o.setOrder_id(rs.getInt("order_id"));
            o.setDeliver_status(rs.getString("deliver_status"));
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        return o.getOrder_id() + " : " + o.getDeliver_status();
    }


    // Also join, this one is an alternative join method to payment join. this one might be better.
    // As a customer, i can get all the info about the stores
    public ArrayList<Store> getStores() throws SQLException {
        ArrayList<Store> stores = new ArrayList<>();
        String sql = "Select * from Store_Address sa join Store_Contact_Info sci ON sa.fullname = sci.fullname and sa.phone = sci.phone join Store_Operating_Hour soh on soh.fullname = sci.fullname and soh.address = sa.address";
        ResultSet rs;
        PreparedStatement ps =conn.prepareStatement(sql);
        rs = ps.executeQuery();
        addToStores(stores,rs);
        return stores;
    }

    private void addToStores(ArrayList<Store> stores, ResultSet rs) throws SQLException{
        while(rs.next()) {
            Store store = new Store();
            store.setStore_id(rs.getInt("store_id"));
            store.setAddress(rs.getString("address"));
            store.setFullname(rs.getString("fullname"));
            store.setClose_hour(rs.getString("close_hour"));
            store.setOpen_hour(rs.getString("open_hour"));
            store.setPhone(rs.getString("phone"));
            store.setRating(rs.getInt("rating"));
            store.setType(rs.getString("type"));
            stores.add(store);
        }
    }

}
