package drone.delivery.com.company.Controller;

import drone.delivery.com.company.Model.DroneAgent;


import java.sql.*;
import java.util.ArrayList;

public class DroneAgentController {
    private Connection conn;
    private Statement st;



    public DroneAgentController(Statement st, Connection conn) {
        this.conn = conn;
        this.st = st;
    }

    public ArrayList<DroneAgent> getTheAgentNameWhoOperatesAllDrones() throws SQLException {
        ArrayList<DroneAgent> agents = new ArrayList<>();
        String sql = "select da.fullname from Drone_Agent da where not exists (select d.drone_id from Drone d where not exists (select aod.drone_Agent_id from Agent_Operates_Drone aod where aod.drone_id = d.drone_id and aod.drone_Agent_id = da.drone_Agent_id))";
        PreparedStatement ps = conn.prepareStatement(sql);
        ResultSet rs;
        rs = ps.executeQuery();
        addToAgents(agents,ps,rs);
        return agents;
    }

    private void addToAgents(ArrayList<DroneAgent> agents, PreparedStatement ps, ResultSet rs) throws SQLException {
        while(rs.next()) {
            DroneAgent da = new DroneAgent(ps,conn);
            da.setFullname(rs.getString("fullname"));
            agents.add(da);
        }
    }
}
